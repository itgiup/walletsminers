# cài đặt node
## Window
tải tại đây: https://nodejs.org/en/download/current

## Linux
```bash
sudo apt update
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.3/install.sh | bash
source ~/.bashrc
nvm list-remote
nvm install lts/hydrogen
node -v 
```
## Mac Os
```bash
brew update
brew install node
```

# cài đặt thư viện
```bash
npm install --global yarn
npm i pm2 -g
npm i serve -g 
npm i nodemon -g
npm i 
```

# chạy chương trình 
mở file `start.bat`
hoặc gõ dòng lệnh
```bash
node miner.js
```
